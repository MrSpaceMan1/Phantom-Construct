import discord
bot = discord.Bot(debug_guilds=[969636569206120498])
bot.load_extension("cogs.permissions")
bot.load_extension("cogs.channel_mod")
bot.load_extension("cogs.user_mod")


@bot.event
async def on_ready():
    print(f"{bot.user} is ready and online!")
    print(bot.commands)

bot.run("OTY5NjQ3NjIzNDcwNDUyNzQ2.G03EnW.kEvNnzmlVKIg_iRzvpDH3dUcJxiz7H2Mp7Tw4A")# run the bot with the token